#!/usr/bin/env python3
from pathlib import Path
import json, re, shutil, html


ROOT=Path(__file__).resolve().parents[1]
import gzip
LANGS={'ko':{'name':'한국어','html':'ko','og':'ko_KR'},'en':{'name':'English','html':'en','og':'en_US'},'ja':{'name':'日本語','html':'ja','og':'ja_JP'},'es':{'name':'Español','html':'es','og':'es_ES'}}
TRANSLATIONS={}
for _lang in ('en','ja','es'):
    with gzip.open(Path(__file__).resolve().parents[1]/'i18n'/f'{_lang}.json.gz','rt',encoding='utf-8') as _f: TRANSLATIONS[_lang]=json.load(_f)
EN=TRANSLATIONS['en']
DIST=ROOT/'dist'
BASE='https://gsh4124-cyber.github.io/pc-checkup/'
PAGES=['index.html','checkup.html','mobile.html','keyboard.html','mouse.html','mic.html','webcam.html','speaker.html','display.html']
ASSETS=['app.js','mobile.js','styles.css']
LANG_ORDER=['ko','en','ja','es']

JS_SPECIAL={
'en':{
'${label}를 사용할 수 없습니다.':'${label} is unavailable.',
'${label} 권한이 차단되었습니다. 브라우저 주소창의 권한 설정을 확인하세요.':'${label} permission is blocked. Check browser site permissions.',
'사용 가능한 ${label} 장치를 찾지 못했습니다.':'No available ${label} device was found.',
'${label}가 다른 프로그램에서 사용 중이거나 장치를 열 수 없습니다.':'${label} is being used by another app or cannot be opened.',
'${label}의 요청 설정을 사용할 수 없습니다. 다른 장치를 선택해보세요.':'The requested ${label} settings are unavailable. Try another device.',
'${label}를 사용할 수 없습니다. (${err.name || "알 수 없는 오류"})':'${label} is unavailable. (${err.name || "Unknown error"})',
'카메라 ${i+1}':'Camera ${i+1}','${done} / 6 완료':'${done} / 6 complete',
'카메라 입력 정상':'Camera input active','전/후면 연결 확인 완료':'Front/rear connection confirmed','${k} 권한이 차단되었습니다. 브라우저 권한 설정을 확인하세요.':'${k} permission is blocked. Check browser permissions.','사용 가능한 ${k} 장치를 찾지 못했습니다.':'No available ${k} device was found.','${k} 장치를 사용할 수 없습니다. 다른 앱이 사용 중인지 확인하세요.':'${k} device is unavailable. Check whether another app is using it.','${k}를 시작하지 못했습니다':'Could not start ${k}','${done} / ${tests.length} 완료':'${done} / ${tests.length} complete','Camera 입력 OK':'Camera input OK','서로 다른 전/후면 입력 확인':'distinct front/rear inputs confirmed',
},
'ja':{
'${label}를 사용할 수 없습니다.':'${label}を使用できません。','${label} 권한이 차단되었습니다. 브라우저 주소창의 권한 설정을 확인하세요.':'${label}の権限がブロックされています。ブラウザのサイト権限を確認してください。','사용 가능한 ${label} 장치를 찾지 못했습니다.':'使用可能な${label}デバイスが見つかりません。','${label}가 다른 프로그램에서 사용 중이거나 장치를 열 수 없습니다.':'${label}が別のアプリで使用中か、デバイスを開けません。','${label}의 요청 설정을 사용할 수 없습니다. 다른 장치를 선택해보세요.':'要求された${label}設定を使用できません。別のデバイスを選択してください。','${label}를 사용할 수 없습니다. (${err.name || "알 수 없는 오류"})':'${label}を使用できません。(${err.name || "不明なエラー"})','카메라 ${i+1}':'カメラ ${i+1}','${done} / 6 완료':'${done} / 6 完了','카메라 입력 정상':'カメラ入力正常','전/후면 연결 확인 완료':'前面/背面の接続確認完了','${k} 권한이 차단되었습니다. 브라우저 권한 설정을 확인하세요.':'${k}の権限がブロックされています。ブラウザの権限設定を確認してください。','사용 가능한 ${k} 장치를 찾지 못했습니다.':'使用可能な${k}デバイスが見つかりません。','${k} 장치를 사용할 수 없습니다. 다른 앱이 사용 중인지 확인하세요.':'${k}デバイスを使用できません。他のアプリが使用中でないか確認してください。','${k}를 시작하지 못했습니다':'${k}を開始できませんでした','${done} / ${tests.length} 완료':'${done} / ${tests.length} 完了','Camera 입력 OK':'カメラ入力正常','서로 다른 전/후면 입력 확인':'異なる前面/背面入力を確認',
},
'es':{
'${label}를 사용할 수 없습니다.':'${label} no está disponible.','${label} 권한이 차단되었습니다. 브라우저 주소창의 권한 설정을 확인하세요.':'El permiso de ${label} está bloqueado. Revisa los permisos del sitio en el navegador.','사용 가능한 ${label} 장치를 찾지 못했습니다.':'No se encontró ningún dispositivo de ${label} disponible.','${label}가 다른 프로그램에서 사용 중이거나 장치를 열 수 없습니다.':'Otro programa está usando ${label} o no se puede abrir el dispositivo.','${label}의 요청 설정을 사용할 수 없습니다. 다른 장치를 선택해보세요.':'La configuración solicitada de ${label} no está disponible. Prueba otro dispositivo.','${label}를 사용할 수 없습니다. (${err.name || "알 수 없는 오류"})':'${label} no está disponible. (${err.name || "Error desconocido"})','카메라 ${i+1}':'Cámara ${i+1}','${done} / 6 완료':'${done} / 6 completadas','카메라 입력 정상':'Entrada de cámara activa','전/후면 연결 확인 완료':'Conexión frontal/trasera confirmada','${k} 권한이 차단되었습니다. 브라우저 권한 설정을 확인하세요.':'El permiso de ${k} está bloqueado. Revisa los permisos del navegador.','사용 가능한 ${k} 장치를 찾지 못했습니다.':'No se encontró un dispositivo de ${k} disponible.','${k} 장치를 사용할 수 없습니다. 다른 앱이 사용 중인지 확인하세요.':'El dispositivo de ${k} no está disponible. Comprueba si otra aplicación lo está usando.','${k}를 시작하지 못했습니다':'No se pudo iniciar ${k}','${done} / ${tests.length} 완료':'${done} / ${tests.length} completadas','Camera 입력 OK':'Entrada de cámara correcta','서로 다른 전/후면 입력 확인':'entradas frontal/trasera distintas confirmadas',
}}


def translate_text(src, lang):
    if lang=='ko': return src
    table=TRANSLATIONS[lang]
    # longest first avoids a short label changing a longer sentence first
    for k in sorted(EN.keys(), key=len, reverse=True):
        v=table.get(k, EN[k])
        src=src.replace(k,v)
    return src


def translate_js(src, lang):
    if lang=='ko': return src
    src=translate_text(src,lang)
    for k,v in JS_SPECIAL[lang].items(): src=src.replace(k,v)
    return src


def page_path(lang,page):
    if lang=='ko': return '' if page=='index.html' else page
    return f'{lang}/' if page=='index.html' else f'{lang}/{page}'


def canonical(lang,page): return BASE+page_path(lang,page)


def strip_old_seo(s):
    patterns=[
      r'<link rel="canonical"[^>]*>', r'<link rel="alternate"[^>]*>',
      r'<meta property="og:[^"]+"[^>]*>', r'<meta name="twitter:[^"]+"[^>]*>',
      r'<script type="application/ld\+json">.*?</script>'
    ]
    for p in patterns:s=re.sub(p,'',s,flags=re.S|re.I)
    return s


def get_title_desc(s):
    t=re.search(r'<title>(.*?)</title>',s,re.S|re.I)
    d=re.search(r'<meta name="description" content="(.*?)">',s,re.S|re.I)
    return html.unescape(t.group(1).strip()) if t else 'DEVICE CHECKUP', html.unescape(d.group(1).strip()) if d else ''


def seo_tags(lang,page,title,desc):
    url=canonical(lang,page); meta=LANGS[lang]
    alts=''.join(f'<link rel="alternate" hreflang="{LANGS[l]["html"]}" href="{canonical(l,page)}">' for l in LANG_ORDER)
    alts+=f'<link rel="alternate" hreflang="x-default" href="{canonical("en",page)}">'
    ld={"@context":"https://schema.org","@type":"WebApplication","name":title,"url":url,"description":desc,"applicationCategory":"UtilitiesApplication","operatingSystem":"Any","inLanguage":meta['html'],"isAccessibleForFree":True}
    return (f'<link rel="canonical" href="{url}">{alts}'
            f'<meta property="og:type" content="website"><meta property="og:locale" content="{meta["og"]}"><meta property="og:site_name" content="DEVICE CHECKUP">'
            f'<meta property="og:title" content="{html.escape(title,quote=True)}"><meta property="og:description" content="{html.escape(desc,quote=True)}"><meta property="og:url" content="{url}">'
            f'<meta name="twitter:card" content="summary"><meta name="twitter:title" content="{html.escape(title,quote=True)}"><meta name="twitter:description" content="{html.escape(desc,quote=True)}">'
            f'<script type="application/ld+json">{json.dumps(ld,ensure_ascii=False,separators=(",",":"))}</script>')


def selector(lang,page):
    opts=''.join(f'<option value="{l}"'+(' selected' if l==lang else '')+f'>{LANGS[l]["name"]}</option>' for l in LANG_ORDER)
    # same page, switch only the language prefix
    js=("const p="+json.dumps(page)+";const l=this.value;const b='/pc-checkup/';"
        "location.href=b+(l==='ko'?(p==='index.html'?'':p):(l+'/'+(p==='index.html'?'':p)));" )
    return f'<div class="lang-switch"><select aria-label="Language" onchange="{html.escape(js,quote=True)}">{opts}</select></div>'


def inject_common(s,lang,page):
    s=strip_old_seo(s)
    s=re.sub(r'<html lang="[^"]+"',f'<html lang="{LANGS[lang]["html"]}"',s,count=1)
    title,desc=get_title_desc(s)
    s=s.replace('</head>',seo_tags(lang,page,title,desc)+'</head>',1)
    s=s.replace('<nav class="navlinks">',selector(lang,page)+'<nav class="navlinks">',1)
    style='''<style>.lang-switch{margin-left:auto}.lang-switch select{background:#0d141d;color:#f4f7fb;border:1px solid #273445;border-radius:10px;padding:8px 9px;font-weight:700;max-width:125px}@media(max-width:600px){.nav{gap:8px}.lang-switch select{max-width:110px;padding:7px 6px;font-size:12px}}</style>'''
    s=s.replace('</head>',style+'</head>',1)
    return s


def main():
    if DIST.exists(): shutil.rmtree(DIST)
    DIST.mkdir()
    # root Korean
    for a in ASSETS: shutil.copy2(ROOT/a,DIST/a)
    for page in PAGES:
        s=(ROOT/page).read_text(encoding='utf-8')
        s=inject_common(s,'ko',page)
        (DIST/page).write_text(s,encoding='utf-8')
    # localized copies
    for lang in LANG_ORDER[1:]:
        d=DIST/lang;d.mkdir()
        shutil.copy2(ROOT/'styles.css',d/'styles.css')
        (d/'app.js').write_text(translate_js((ROOT/'app.js').read_text(encoding='utf-8'),lang),encoding='utf-8')
        (d/'mobile.js').write_text(translate_js((ROOT/'mobile.js').read_text(encoding='utf-8'),lang),encoding='utf-8')
        for page in PAGES:
            s=translate_text((ROOT/page).read_text(encoding='utf-8'),lang)
            s=inject_common(s,lang,page)
            (d/page).write_text(s,encoding='utf-8')
    # sitemap all indexable pages
    urls=[]
    for lang in LANG_ORDER:
        for page in PAGES: urls.append(canonical(lang,page))
    sm='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+''.join(f'  <url><loc>{u}</loc></url>\n' for u in urls)+'</urlset>\n'
    (DIST/'sitemap.xml').write_text(sm,encoding='utf-8')
    (DIST/'robots.txt').write_text('User-agent: *\nAllow: /\n\nSitemap: '+BASE+'sitemap.xml\n',encoding='utf-8')
    # QA report
    report=[]
    for lang in LANG_ORDER[1:]:
        for page in PAGES:
            s=(DIST/lang/page).read_text(encoding='utf-8')
            # Korean visible/source leakage is a localization blocker; comments are not used in these HTMLs.
            if re.search(r'[가-힣]',s.replace('한국어','')): report.append(f'KOREAN_LEAK {lang}/{page}')
        for js in ['app.js','mobile.js']:
            s=(DIST/lang/js).read_text(encoding='utf-8')
            if re.search(r'[가-힣]',s): report.append(f'KOREAN_JS_LEAK {lang}/{js}')
    if report:
        print('\n'.join(report)); raise SystemExit(2)
    print(f'Built {len(LANG_ORDER)} languages × {len(PAGES)} pages = {len(LANG_ORDER)*len(PAGES)} localized/indexable URLs')

if __name__=='__main__': main()
